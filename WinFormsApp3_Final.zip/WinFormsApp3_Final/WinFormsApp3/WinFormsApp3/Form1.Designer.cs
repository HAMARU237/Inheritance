﻿namespace WinFormsApp3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPikachu = new Button();
            btnCharizard = new Button();
            btnBulbasaur = new Button();
            btnSquirtle = new Button();
            btnJigglypuff = new Button();
            btnMeowth = new Button();
            label1 = new Label();
            lblPokemonName = new Label();
            lblPokemonType = new Label();
            lblPokemonStatus = new Label();
            pictureBox1 = new PictureBox();
            maskedTextBox1 = new MaskedTextBox();
            maskedTextBox2 = new MaskedTextBox();
            maskedTextBox3 = new MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnPikachu
            // 
            btnPikachu.Location = new Point(77, 44);
            btnPikachu.Name = "btnPikachu";
            btnPikachu.Size = new Size(94, 29);
            btnPikachu.TabIndex = 0;
            btnPikachu.Text = "Pikachu";
            btnPikachu.UseVisualStyleBackColor = true;
            btnPikachu.Click += btnPikachu_Click;
            // 
            // btnCharizard
            // 
            btnCharizard.Location = new Point(77, 102);
            btnCharizard.Name = "btnCharizard";
            btnCharizard.Size = new Size(94, 29);
            btnCharizard.TabIndex = 1;
            btnCharizard.Text = "Charizard";
            btnCharizard.UseVisualStyleBackColor = true;
            btnCharizard.Click += btnCharizard_Click;
            // 
            // btnBulbasaur
            // 
            btnBulbasaur.Location = new Point(77, 161);
            btnBulbasaur.Name = "btnBulbasaur";
            btnBulbasaur.Size = new Size(94, 29);
            btnBulbasaur.TabIndex = 2;
            btnBulbasaur.Text = "Bulbasaur";
            btnBulbasaur.UseVisualStyleBackColor = true;
            btnBulbasaur.Click += btnBulbasaur_Click;
            // 
            // btnSquirtle
            // 
            btnSquirtle.Location = new Point(77, 220);
            btnSquirtle.Name = "btnSquirtle";
            btnSquirtle.Size = new Size(94, 29);
            btnSquirtle.TabIndex = 3;
            btnSquirtle.Text = "Squirtle";
            btnSquirtle.UseVisualStyleBackColor = true;
            btnSquirtle.Click += btnSquirtle_Click;
            // 
            // btnJigglypuff
            // 
            btnJigglypuff.Location = new Point(77, 282);
            btnJigglypuff.Name = "btnJigglypuff";
            btnJigglypuff.Size = new Size(94, 29);
            btnJigglypuff.TabIndex = 4;
            btnJigglypuff.Text = "Jigglypuff";
            btnJigglypuff.UseVisualStyleBackColor = true;
            btnJigglypuff.Click += btnJigglypuff_Click;
            // 
            // btnMeowth
            // 
            btnMeowth.Location = new Point(77, 349);
            btnMeowth.Name = "btnMeowth";
            btnMeowth.Size = new Size(94, 29);
            btnMeowth.TabIndex = 5;
            btnMeowth.Text = "Meowth";
            btnMeowth.UseVisualStyleBackColor = true;
            btnMeowth.Click += btnMeowth_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(580, 26);
            label1.Name = "label1";
            label1.Size = new Size(97, 20);
            label1.TabIndex = 6;
            label1.Text = "pickPokemon";
            label1.Click += label1_Click;
            // 
            // lblPokemonName
            // 
            lblPokemonName.AutoSize = true;
            lblPokemonName.Location = new Point(913, 136);
            lblPokemonName.Name = "lblPokemonName";
            lblPokemonName.Size = new Size(46, 20);
            lblPokemonName.TabIndex = 7;
            lblPokemonName.Text = "name";
            lblPokemonName.Click += label2_Click;
            // 
            // lblPokemonType
            // 
            lblPokemonType.AutoSize = true;
            lblPokemonType.Location = new Point(913, 190);
            lblPokemonType.Name = "lblPokemonType";
            lblPokemonType.Size = new Size(40, 20);
            lblPokemonType.TabIndex = 8;
            lblPokemonType.Text = "Tpye";
            lblPokemonType.Click += label3_Click;
            // 
            // lblPokemonStatus
            // 
            lblPokemonStatus.AutoSize = true;
            lblPokemonStatus.Location = new Point(913, 240);
            lblPokemonStatus.Name = "lblPokemonStatus";
            lblPokemonStatus.Size = new Size(47, 20);
            lblPokemonStatus.TabIndex = 9;
            lblPokemonStatus.Text = "status";
            lblPokemonStatus.Click += label4_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(339, 79);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(526, 449);
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(998, 132);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(125, 27);
            maskedTextBox1.TabIndex = 11;
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.Location = new Point(998, 190);
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(125, 27);
            maskedTextBox2.TabIndex = 12;
            // 
            // maskedTextBox3
            // 
            maskedTextBox3.Location = new Point(998, 240);
            maskedTextBox3.Name = "maskedTextBox3";
            maskedTextBox3.Size = new Size(125, 27);
            maskedTextBox3.TabIndex = 13;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1352, 575);
            Controls.Add(maskedTextBox3);
            Controls.Add(maskedTextBox2);
            Controls.Add(maskedTextBox1);
            Controls.Add(pictureBox1);
            Controls.Add(lblPokemonStatus);
            Controls.Add(lblPokemonType);
            Controls.Add(lblPokemonName);
            Controls.Add(label1);
            Controls.Add(btnMeowth);
            Controls.Add(btnJigglypuff);
            Controls.Add(btnSquirtle);
            Controls.Add(btnBulbasaur);
            Controls.Add(btnCharizard);
            Controls.Add(btnPikachu);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPikachu;
        private Button btnCharizard;
        private Button btnBulbasaur;
        private Button btnSquirtle;
        private Button btnJigglypuff;
        private Button btnMeowth;
        private Label label1;
        private Label lblPokemonName;
        private Label lblPokemonType;
        private Label lblPokemonStatus;
        private PictureBox pictureBox1;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox maskedTextBox2;
        private MaskedTextBox maskedTextBox3;
    }
}
